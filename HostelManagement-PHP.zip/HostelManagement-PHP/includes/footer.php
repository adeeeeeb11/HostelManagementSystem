<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - <a href="thankss.php" <span style="color: #0000FF;">HOSTEL MANAGEMENT - Developed by SEK KELATE</span>
</footer>
