<?php
    session_start();
    
    if(isset($_POST['login']))
    {
        // Your login logic here...

        if($rs){
            // Your login success logic here...
            header("location: student/dashboard.php");
        } else {
            echo "<script>alert('Sorry, Invalid Username/Email or Password!');</script>";
        }
    }
?>

<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="background" type="image/png" sizes="16x16" href="assets/images/sek_kito.png">
    <title>Hostel Management System</title>
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div class="main-wrapper">
        <!-- Your authentication UI here... -->
    </div>

    <script src="assets/libs/jquery/dist/jquery.min.js "></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js "></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js "></script>
    <script>
        $(".preloader ").fadeOut();
    </script>
</body>

</html>
